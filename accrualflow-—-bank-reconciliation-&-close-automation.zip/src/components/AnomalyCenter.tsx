import React, { useState } from 'react';
import { AnomalyItem, BankTransaction } from '../types';
import { 
  AlertTriangle, 
  ShieldAlert, 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  FileText, 
  ArrowUpRight,
  HelpCircle,
  Clock,
  Layers,
  Check
} from 'lucide-react';

interface AnomalyCenterProps {
  anomalies: AnomalyItem[];
  bankTransactions: BankTransaction[];
  onResolveAnomaly: (id: string, actionNote: string) => void;
  onDismissAnomaly: (id: string) => void;
  onPostAdjustEntry: (anomaly: AnomalyItem) => void;
  isPeriodLocked: boolean;
}

export const AnomalyCenter: React.FC<AnomalyCenterProps> = ({
  anomalies,
  bankTransactions,
  onResolveAnomaly,
  onDismissAnomaly,
  onPostAdjustEntry,
  isPeriodLocked,
}) => {
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [activeAnomalyForAi, setActiveAnomalyForAi] = useState<AnomalyItem | null>(null);
  const [isAiInvestigating, setIsAiInvestigating] = useState<boolean>(false);
  const [resolutionNoteInput, setResolutionNoteInput] = useState<string>('');

  const filteredAnomalies = anomalies.filter(item => {
    if (filterSeverity !== 'all' && item.severity !== filterSeverity) return false;
    if (filterStatus !== 'all' && item.resolutionStatus !== filterStatus) return false;
    return true;
  });

  const handleInvestigate = async (anomaly: AnomalyItem) => {
    setActiveAnomalyForAi(anomaly);
    setIsAiInvestigating(true);

    const relatedTx = bankTransactions.find(t => t.id === anomaly.transactionId);

    try {
      const response = await fetch('/api/ai/investigate-anomaly', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          anomaly,
          transaction: relatedTx,
          bankAccount: anomaly.bankAccount,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setActiveAnomalyForAi(prev => prev ? { ...prev, aiAnalysis: data.analysis } : null);
      }
    } catch (err) {
      console.warn('AI investigation error:', err);
    } finally {
      setIsAiInvestigating(false);
    }
  };

  const formatCurrency = (val: number) => {
    const isNeg = val < 0;
    const formatted = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(Math.abs(val));
    return isNeg ? `(${formatted})` : formatted;
  };

  return (
    <div className="space-y-4">
      {/* Risk Center Banner */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-white flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
            Accounting Anomaly & Fraud Risk Monitor
          </h2>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span>Automated checks for duplicate disbursements</span>
            <span aria-hidden="true">·</span>
            <span>Timing cutoffs</span>
            <span aria-hidden="true">·</span>
            <span>Unrecorded processor fees</span>
            <span aria-hidden="true">·</span>
            <span>SOX missing receipt violations</span>
          </div>
        </div>

        {/* Severity & Status Filters */}
        <div className="flex items-center gap-2">
          <div className="flex items-center p-0.5 bg-slate-950 border border-slate-800 rounded-lg text-xs">
            {['all', 'high', 'medium', 'low'].map(sev => (
              <button
                key={sev}
                onClick={() => setFilterSeverity(sev)}
                className={`px-2.5 py-1 capitalize rounded transition-colors ${
                  filterSeverity === sev
                    ? 'bg-slate-800 text-white font-medium shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {sev}
              </button>
            ))}
          </div>

          <div className="flex items-center p-0.5 bg-slate-950 border border-slate-800 rounded-lg text-xs">
            {['all', 'open', 'resolved'].map(stat => (
              <button
                key={stat}
                onClick={() => setFilterStatus(stat)}
                className={`px-2.5 py-1 capitalize rounded transition-colors ${
                  filterStatus === stat
                    ? 'bg-slate-800 text-white font-medium shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {stat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Anomaly Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredAnomalies.length === 0 ? (
          <div className="col-span-2 p-12 text-center bg-slate-900/40 border border-slate-800 rounded-xl text-slate-500 text-xs">
            No anomalies found matching current filters. All accounts are within normal risk parameters.
          </div>
        ) : (
          filteredAnomalies.map(item => {
            const isResolved = item.resolutionStatus === 'resolved';

            return (
              <div
                key={item.id}
                className={`bg-slate-900/60 border rounded-xl p-4 flex flex-col justify-between transition-all ${
                  isResolved
                    ? 'border-slate-800/80 opacity-75'
                    : item.severity === 'high'
                    ? 'border-rose-500/30 hover:border-rose-500/50'
                    : item.severity === 'medium'
                    ? 'border-amber-500/30 hover:border-amber-500/50'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
                      <span>{item.date}</span>
                      <span aria-hidden="true">·</span>
                      <span>{item.bankAccount}</span>
                      <span aria-hidden="true">·</span>
                      <span className={`capitalize ${
                        item.severity === 'high' 
                          ? 'text-rose-400 font-semibold' 
                          : item.severity === 'medium' 
                          ? 'text-amber-400 font-semibold' 
                          : 'text-slate-400'
                      }`}>
                        {item.severity} Risk
                      </span>
                    </div>

                    <div className="font-mono tabular-nums text-sm font-bold text-white">
                      {formatCurrency(item.amount)}
                    </div>
                  </div>

                  <h3 className="text-sm font-semibold text-slate-100 mb-1.5">
                    {item.title}
                  </h3>

                  <p className="text-xs text-slate-300 leading-relaxed mb-3">
                    {item.description}
                  </p>

                  {item.notes && (
                    <div className="text-[11px] text-slate-400 bg-slate-950/60 border border-slate-800 rounded-lg p-2.5 mb-3">
                      <strong className="text-slate-300">Auditor / Staff Note:</strong> {item.notes}
                    </div>
                  )}
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2 mt-auto">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <span className={`inline-block w-2 h-2 rounded-full ${isResolved ? 'bg-emerald-400' : 'bg-amber-400'}`} />
                    <span className="capitalize">{item.resolutionStatus}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleInvestigate(item)}
                      className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-750 text-indigo-300 border border-indigo-500/20 flex items-center gap-1.5 transition-colors"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Investigate (AI)</span>
                    </button>

                    {!isResolved && (
                      <button
                        onClick={() => onResolveAnomaly(item.id, 'Resolved via risk review')}
                        disabled={isPeriodLocked}
                        className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1 transition-colors"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Resolve</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* AI Investigation Modal / Drawer */}
      {activeAnomalyForAi && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-3">
              <div>
                <div className="flex items-center gap-2 text-xs text-indigo-400 font-semibold mb-1">
                  <Sparkles className="w-4 h-4" />
                  Senior Controller AI Analysis
                </div>
                <h3 className="text-base font-bold text-white">
                  {activeAnomalyForAi.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveAnomalyForAi(null)}
                className="text-slate-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            {isAiInvestigating ? (
              <div className="py-12 flex flex-col items-center justify-center gap-3 text-slate-400">
                <Sparkles className="w-6 h-6 text-indigo-400 animate-spin" />
                <span className="text-xs">Analyzing transaction history, vendor statements, and GAAP standards...</span>
              </div>
            ) : activeAnomalyForAi.aiAnalysis ? (
              <div className="space-y-4 text-xs">
                {/* Executive Summary */}
                <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3.5">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    Risk Assessment & Materiality
                  </div>
                  <p className="text-slate-200 leading-relaxed">
                    {activeAnomalyForAi.aiAnalysis.summary}
                  </p>
                </div>

                {/* Root Cause Hypothesis */}
                <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3.5">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    Root Cause Hypothesis
                  </div>
                  <p className="text-slate-200 leading-relaxed">
                    {activeAnomalyForAi.aiAnalysis.rootCauseHypothesis}
                  </p>
                </div>

                {/* GAAP & SOX Implication */}
                <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3.5">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    GAAP & Internal Control Standard
                  </div>
                  <p className="text-slate-200 leading-relaxed">
                    {activeAnomalyForAi.aiAnalysis.gaapImplication}
                  </p>
                </div>

                {/* Suggested Action & Journal Entry */}
                {activeAnomalyForAi.aiAnalysis.suggestedJournalEntry?.needed && (
                  <div className="bg-indigo-950/30 border border-indigo-500/30 rounded-xl p-3.5 space-y-2">
                    <div className="text-[11px] font-semibold text-indigo-300 uppercase tracking-wider">
                      Proposed Adjusting Journal Entry
                    </div>
                    <div className="grid grid-cols-2 gap-2 font-mono text-[11px] bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                      <div>
                        <span className="text-slate-400">Debit:</span>{' '}
                        <span className="text-white">{activeAnomalyForAi.aiAnalysis.suggestedJournalEntry.debitAccount}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-emerald-400">
                          {formatCurrency(activeAnomalyForAi.aiAnalysis.suggestedJournalEntry.amount)}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400">Credit:</span>{' '}
                        <span className="text-white">{activeAnomalyForAi.aiAnalysis.suggestedJournalEntry.creditAccount}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-slate-200">
                          {formatCurrency(activeAnomalyForAi.aiAnalysis.suggestedJournalEntry.amount)}
                        </span>
                      </div>
                    </div>
                    <div className="text-[11px] text-slate-400 italic">
                      Memo: {activeAnomalyForAi.aiAnalysis.suggestedJournalEntry.memo}
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                  <button
                    onClick={() => setActiveAnomalyForAi(null)}
                    className="px-4 py-2 rounded-lg text-xs font-medium text-slate-300 hover:text-white"
                  >
                    Close Review
                  </button>

                  {activeAnomalyForAi.aiAnalysis.suggestedJournalEntry?.needed && (
                    <button
                      onClick={() => {
                        onPostAdjustEntry(activeAnomalyForAi);
                        setActiveAnomalyForAi(null);
                      }}
                      disabled={isPeriodLocked}
                      className="px-4 py-2 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm transition-colors"
                    >
                      Post Adjusting Journal Entry
                    </button>
                  )}

                  <button
                    onClick={() => {
                      onResolveAnomaly(activeAnomalyForAi.id, 'Resolved with Controller AI validation');
                      setActiveAnomalyForAi(null);
                    }}
                    disabled={isPeriodLocked}
                    className="px-4 py-2 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm transition-colors"
                  >
                    Mark Anomaly Resolved
                  </button>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
};
