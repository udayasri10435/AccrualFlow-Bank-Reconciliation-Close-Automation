import React, { useState } from 'react';
import { 
  CloseChecklistItem, 
  BankAccountSummary, 
  CloseSummaryData 
} from '../types';
import { 
  CheckCircle2, 
  Circle, 
  Lock, 
  Unlock, 
  Sparkles, 
  FileCheck, 
  ShieldCheck, 
  Calendar,
  UserCheck,
  Building,
  Printer,
  FileSpreadsheet
} from 'lucide-react';

interface CloseTrackerProps {
  checklist: CloseChecklistItem[];
  bankAccounts: BankAccountSummary[];
  onToggleChecklistItem: (id: string, signedBy?: string) => void;
  isPeriodLocked: boolean;
  onTogglePeriodLock: () => void;
  period: string;
  matchedCount: number;
  unmatchedCount: number;
}

export const CloseTracker: React.FC<CloseTrackerProps> = ({
  checklist,
  bankAccounts,
  onToggleChecklistItem,
  isPeriodLocked,
  onTogglePeriodLock,
  period,
  matchedCount,
  unmatchedCount,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [signerName, setSignerName] = useState<string>('Sarah Lin, CPA');
  const [aiCloseSummary, setAiCloseSummary] = useState<CloseSummaryData | null>(null);
  const [isGeneratingAi, setIsGeneratingAi] = useState<boolean>(false);

  // Aggregated tie-out balances across all operating accounts
  const totalStatementBalance = bankAccounts.reduce((sum, b) => sum + b.statementEndingBalance, 0);
  const totalGlBalance = bankAccounts.reduce((sum, b) => sum + b.glEndingBalance, 0);
  const totalDepositsInTransit = bankAccounts.reduce((sum, b) => sum + b.depositsInTransit, 0);
  const totalOutstandingChecks = bankAccounts.reduce((sum, b) => sum + b.outstandingChecks, 0);
  const totalAdjustedBankBalance = totalStatementBalance + totalDepositsInTransit - totalOutstandingChecks;
  const netVariance = totalAdjustedBankBalance - totalGlBalance;
  const isFullyTiedOut = Math.abs(netVariance) < 0.01;

  const completedCount = checklist.filter(c => c.status === 'completed').length;
  const progressPercent = Math.round((completedCount / checklist.length) * 100);

  const categories = ['all', 'Cash & Banking', 'Revenue & AR', 'Accruals & Prepaids', 'Payroll & Tax', 'Reporting & Sign-off'];

  const filteredItems = checklist.filter(item => {
    if (selectedCategory !== 'all' && item.category !== selectedCategory) return false;
    return true;
  });

  const handleGenerateAiSummary = async () => {
    setIsGeneratingAi(true);
    try {
      const response = await fetch('/api/ai/close-summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          period,
          stats: { matched: matchedCount, anomalies: 0 },
          unmatchedCount,
          reconciledBalance: totalGlBalance,
          bankBalance: totalStatementBalance,
          variance: netVariance,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setAiCloseSummary(data.summary);
      }
    } catch (e) {
      console.warn('Close summary generation error:', e);
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(val);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner: Period Close Status & Tie-Out Schedule */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800/80 pb-4 mb-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-indigo-400 font-semibold mb-1">
              <Calendar className="w-4 h-4" />
              <span>Accounting Close Cycle</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="font-mono text-white">{period}</span>
            </div>
            <h2 className="text-lg font-bold text-white">
              Month-End Close Automation & Ledger Sign-Off
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleGenerateAiSummary}
              disabled={isGeneratingAi}
              className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm flex items-center gap-1.5 transition-all"
            >
              <Sparkles className={`w-3.5 h-3.5 ${isGeneratingAi ? 'animate-spin' : ''}`} />
              <span>{isGeneratingAi ? 'Generating Commentary...' : 'AI Close Commentary'}</span>
            </button>

            <button
              onClick={onTogglePeriodLock}
              className={`px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors border ${
                isPeriodLocked
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-300 hover:bg-amber-500/20'
                  : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-750 hover:text-white'
              }`}
            >
              {isPeriodLocked ? <Lock className="w-3.5 h-3.5 text-amber-400" /> : <Unlock className="w-3.5 h-3.5 text-slate-400" />}
              <span>{isPeriodLocked ? 'Unlock Accounting Period' : 'Lock Period (NetSuite / QBO)'}</span>
            </button>
          </div>
        </div>

        {/* Master Cash Reconciliation Tie-Out Schedule */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 bg-slate-950/70 border border-slate-800 rounded-xl p-4 text-xs font-mono">
          <div>
            <span className="text-slate-400 block mb-1">1. Bank Ending Balance</span>
            <span className="text-base font-bold text-white tabular-nums">
              {formatCurrency(totalStatementBalance)}
            </span>
          </div>

          <div>
            <span className="text-slate-400 block mb-1">(+) Deposits in Transit</span>
            <span className="text-base font-bold text-emerald-400 tabular-nums">
              +{formatCurrency(totalDepositsInTransit)}
            </span>
          </div>

          <div>
            <span className="text-slate-400 block mb-1">(-) Outstanding Checks</span>
            <span className="text-base font-bold text-slate-300 tabular-nums">
              -{formatCurrency(totalOutstandingChecks)}
            </span>
          </div>

          <div>
            <span className="text-slate-400 block mb-1">(=) Adjusted Cash Balance</span>
            <span className="text-base font-bold text-indigo-300 tabular-nums">
              {formatCurrency(totalAdjustedBankBalance)}
            </span>
          </div>

          <div className="border-l border-slate-800 pl-3">
            <span className="text-slate-400 block mb-1">Net Variance (GL vs Adj)</span>
            <span className={`text-base font-bold tabular-nums ${isFullyTiedOut ? 'text-emerald-400' : 'text-amber-400'}`}>
              {formatCurrency(netVariance)}
            </span>
            <span className="text-[10px] text-slate-500 block font-sans">
              {isFullyTiedOut ? 'Audit Ready ($0.00 Difference)' : 'Pending reconciliation'}
            </span>
          </div>
        </div>
      </div>

      {/* AI Close Package Commentary (if generated) */}
      {aiCloseSummary && (
        <div className="bg-indigo-950/20 border border-indigo-500/30 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-indigo-500/20 pb-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-indigo-300">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              Executive Controller Close Memo (Big 4 & SOX Audit Ready)
            </div>
            <span className="text-[11px] font-mono text-emerald-400 font-semibold bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-500/20">
              {aiCloseSummary.auditOpinion}
            </span>
          </div>

          <h3 className="text-sm font-bold text-white">
            {aiCloseSummary.executiveHeadline}
          </h3>

          <p className="text-xs text-slate-300 leading-relaxed">
            {aiCloseSummary.balanceTieOutNarrative}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs bg-slate-950/60 p-3 rounded-lg border border-slate-800">
            <div>
              <strong className="text-slate-400 block text-[11px] mb-1">Internal Control Assertions</strong>
              <p className="text-slate-300">{aiCloseSummary.internalControlNotes}</p>
            </div>
            <div>
              <strong className="text-slate-400 block text-[11px] mb-1">Sign-Off Recommendation</strong>
              <p className="text-slate-300">{aiCloseSummary.signOffRecommendation}</p>
            </div>
          </div>
        </div>
      )}

      {/* Close Checklist Section */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl overflow-hidden">
        
        {/* Category Filter Tabs */}
        <div className="px-4 py-3 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/80">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-slate-200">Close Milestones & Sign-Offs</span>
            <span className="text-xs text-slate-500">·</span>
            <span className="text-xs text-slate-400">{completedCount} of {checklist.length} Complete ({progressPercent}%)</span>
          </div>

          <div className="flex items-center gap-1 overflow-x-auto text-xs">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded transition-colors whitespace-nowrap ${
                  selectedCategory === cat
                    ? 'bg-slate-800 text-white font-medium shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Checklist Rows */}
        <div className="divide-y divide-slate-800/80">
          {filteredItems.map(item => {
            const isDone = item.status === 'completed';

            return (
              <div
                key={item.id}
                className={`p-4 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors ${
                  isDone ? 'bg-slate-900/20' : 'hover:bg-slate-850/40'
                }`}
              >
                <div className="flex items-start gap-3">
                  <button
                    onClick={() => onToggleChecklistItem(item.id, signerName)}
                    disabled={isPeriodLocked}
                    className={`mt-0.5 shrink-0 transition-transform active:scale-95 ${
                      isDone ? 'text-emerald-400' : 'text-slate-600 hover:text-slate-400'
                    }`}
                  >
                    {isDone ? (
                      <CheckCircle2 className="w-4 h-4 fill-emerald-400/20" />
                    ) : (
                      <Circle className="w-4 h-4" />
                    )}
                  </button>

                  <div>
                    <h4 className={`text-sm font-semibold transition-colors ${
                      isDone ? 'text-slate-300 line-through decoration-slate-600' : 'text-slate-100'
                    }`}>
                      {item.title}
                    </h4>

                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
                      <span>{item.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>Assignee: <strong className="text-slate-300 font-normal">{item.assignee}</strong></span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono text-slate-500">Due {item.dueDate}</span>
                    </div>

                    {item.signedBy && (
                      <div className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1">
                        <UserCheck className="w-3 h-3" />
                        <span>Signed off by {item.signedBy} on {item.completedAt}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="shrink-0 flex items-center gap-2 sm:self-center self-end">
                  <span className="text-[11px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                    {item.signOffRole}
                  </span>

                  <button
                    onClick={() => onToggleChecklistItem(item.id, signerName)}
                    disabled={isPeriodLocked}
                    className={`px-2.5 py-1 rounded text-xs font-medium transition-colors border ${
                      isDone
                        ? 'border-slate-800 bg-slate-950 text-slate-400 hover:text-slate-200'
                        : 'border-indigo-500/40 bg-indigo-950/40 text-indigo-300 hover:bg-indigo-900/60'
                    }`}
                  >
                    {isDone ? 'Revoke Sign-Off' : 'Sign Off'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

      </div>

    </div>
  );
};
