import React, { useState, useEffect } from 'react';
import { BankTransaction, ErpSource } from '../types';
import { PlusCircle, FileText, CheckCircle2, X } from 'lucide-react';

interface AdjustingEntryModalProps {
  bankTx: BankTransaction | null;
  initialDifference?: number;
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (entry: {
    docNumber: string;
    accountCode: string;
    accountName: string;
    amount: number;
    memo: string;
    sourceErp: ErpSource;
  }) => void;
}

export const AdjustingEntryModal: React.FC<AdjustingEntryModalProps> = ({
  bankTx,
  initialDifference = 0,
  isOpen,
  onClose,
  onSubmit,
}) => {
  if (!isOpen || !bankTx) return null;

  const defaultAmount = Math.abs(initialDifference) > 0.001 ? Math.abs(initialDifference) : Math.abs(bankTx.amount);

  const [accountCode, setAccountCode] = useState<string>('6150');
  const [accountName, setAccountName] = useState<string>('Merchant Processing & Interchange Fees');
  const [amount, setAmount] = useState<number>(defaultAmount);
  const [memo, setMemo] = useState<string>(
    initialDifference 
      ? `Reconciliation fee adjustment for ${bankTx.description}`
      : `Bank fee adjustment for ${bankTx.description}`
  );
  const [sourceErp, setSourceErp] = useState<ErpSource>('NetSuite');
  const [docNumber, setDocNumber] = useState<string>(`ADJ-${Date.now().toString().slice(-4)}`);

  useEffect(() => {
    if (bankTx.description.includes('STRIPE')) {
      setAccountCode('6150');
      setAccountName('Merchant Processing & Interchange Fees');
    } else if (bankTx.description.includes('FEE') || bankTx.description.includes('WIRE')) {
      setAccountCode('6140');
      setAccountName('Bank & Wire Service Charges');
    } else if (bankTx.description.includes('AWS')) {
      setAccountCode('6010');
      setAccountName('Hosting & Cloud Infrastructure');
    }
  }, [bankTx]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      docNumber,
      accountCode,
      accountName,
      amount: -amount, // debit expense
      memo,
      sourceErp,
    });
    onClose();
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(val);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
        
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <PlusCircle className="w-5 h-5 text-indigo-400" />
            <h3 className="text-base font-bold text-white">Create Adjusting Journal Entry</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Source Reference Context */}
        <div className="bg-slate-950/70 border border-slate-800 rounded-lg p-3 text-xs">
          <div className="text-slate-400 font-mono text-[11px] mb-1">Source Bank Item</div>
          <div className="text-slate-200 font-medium truncate">{bankTx.description}</div>
          <div className="flex items-center gap-2 text-slate-400 mt-1 font-mono">
            <span>Cleared: {formatCurrency(bankTx.amount)}</span>
            <span aria-hidden="true">·</span>
            <span className="text-indigo-300">Adjustment Needed: {formatCurrency(amount)}</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-medium mb-1">Doc Number</label>
              <input
                type="text"
                required
                value={docNumber}
                onChange={(e) => setDocNumber(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-medium mb-1">Target ERP Ledger</label>
              <select
                value={sourceErp}
                onChange={(e) => setSourceErp(e.target.value as ErpSource)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="NetSuite">NetSuite OneWorld</option>
                <option value="QuickBooks">QuickBooks Online</option>
                <option value="Xero">Xero</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-300 font-medium mb-1">GL Account Code</label>
              <input
                type="text"
                required
                value={accountCode}
                onChange={(e) => setAccountCode(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-slate-300 font-medium mb-1">GL Account Name</label>
              <input
                type="text"
                required
                value={accountName}
                onChange={(e) => setAccountName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Adjustment Amount ($)</label>
            <input
              type="number"
              step="0.01"
              required
              value={amount}
              onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-indigo-500 text-sm font-semibold"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Memo / Audit Justification</label>
            <textarea
              rows={2}
              required
              value={memo}
              onChange={(e) => setMemo(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-300 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold shadow-sm transition-colors"
            >
              Post Adjusting Entry to GL
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
