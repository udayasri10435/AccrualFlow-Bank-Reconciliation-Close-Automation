import React, { useState } from 'react';
import { 
  BankAccountSummary, 
  BankTransaction, 
  GlTransaction, 
  AuditLogEntry, 
  AnomalyItem,
  CloseChecklistItem 
} from '../types';
import { 
  FileSpreadsheet, 
  Download, 
  Printer, 
  ShieldCheck, 
  Search, 
  CheckCircle2, 
  Calendar, 
  Building,
  UserCheck,
  FileText
} from 'lucide-react';

interface AuditBinderProps {
  bankAccounts: BankAccountSummary[];
  bankTransactions: BankTransaction[];
  glTransactions: GlTransaction[];
  auditLogs: AuditLogEntry[];
  anomalies: AnomalyItem[];
  checklist: CloseChecklistItem[];
  period: string;
  isPeriodLocked: boolean;
}

export const AuditBinder: React.FC<AuditBinderProps> = ({
  bankAccounts,
  bankTransactions,
  glTransactions,
  auditLogs,
  anomalies,
  checklist,
  period,
  isPeriodLocked,
}) => {
  const [logSearch, setLogSearch] = useState<string>('');
  const [selectedAccountFilter, setSelectedAccountFilter] = useState<string>('all');

  const totalStatementBalance = bankAccounts.reduce((sum, b) => sum + b.statementEndingBalance, 0);
  const totalGlBalance = bankAccounts.reduce((sum, b) => sum + b.glEndingBalance, 0);
  const totalDepositsInTransit = bankAccounts.reduce((sum, b) => sum + b.depositsInTransit, 0);
  const totalOutstandingChecks = bankAccounts.reduce((sum, b) => sum + b.outstandingChecks, 0);
  const adjustedBalance = totalStatementBalance + totalDepositsInTransit - totalOutstandingChecks;
  const variance = adjustedBalance - totalGlBalance;

  const filteredLogs = auditLogs.filter(log => {
    if (!logSearch) return true;
    const q = logSearch.toLowerCase();
    return log.user.toLowerCase().includes(q) ||
           log.action.toLowerCase().includes(q) ||
           log.details.toLowerCase().includes(q);
  });

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(val);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportCsv = () => {
    const headers = ['Account', 'Bank Balance', 'Deposits In Transit', 'Outstanding Checks', 'Adjusted Balance', 'GL Balance', 'Variance'];
    const rows = bankAccounts.map(b => [
      `"${b.name}"`,
      b.statementEndingBalance,
      b.depositsInTransit,
      b.outstandingChecks,
      b.adjustedBankBalance,
      b.glEndingBalance,
      b.variance
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Bank_Rec_TieOut_${period.replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadJsonBinder = () => {
    const binder = {
      packageTitle: `SOX Audit-Ready Month-End Close Package - ${period}`,
      generatedAt: new Date().toISOString(),
      organization: 'Apex Tech Inc.',
      period,
      periodLocked: isPeriodLocked,
      summaryTieOut: {
        statementBalance: totalStatementBalance,
        depositsInTransit: totalDepositsInTransit,
        outstandingChecks: totalOutstandingChecks,
        adjustedBalance,
        generalLedgerBalance: totalGlBalance,
        variance,
      },
      accounts: bankAccounts,
      checklistSignOffs: checklist,
      anomaliesResolved: anomalies,
      auditTrail: auditLogs,
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(binder, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `Audit_Binder_${period.replace(/\s+/g, '_')}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.removeChild(downloadAnchor);
  };

  return (
    <div className="space-y-6">
      
      {/* Binder Header Actions */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-indigo-400 font-semibold mb-1">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>SOX 404 & GAAP Audit Binder</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="font-mono text-white">{period}</span>
          </div>
          <h2 className="text-lg font-bold text-white">
            Independent Auditor Reconciliation Package
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Compiled tie-out schedules, outstanding items, anomaly resolutions, and immutable sign-off trail
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="px-3 py-2 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 flex items-center gap-1.5 transition-colors"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={handlePrint}
            className="px-3 py-2 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-3.5 h-3.5 text-slate-300" />
            <span>Print Package</span>
          </button>

          <button
            onClick={handleDownloadJsonBinder}
            className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm flex items-center gap-1.5 transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Audit Binder (JSON)</span>
          </button>
        </div>
      </div>

      {/* Formal Audit Tie-Out Schedule Print Ready */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-6 space-y-6">
        <div className="border-b border-slate-800 pb-4 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 uppercase tracking-widest font-mono">
              Consolidated Balance Sheet Tie-Out
            </div>
            <h3 className="text-base font-bold text-white mt-1">
              Apex Tech Inc. & Subsidiaries — Cash & Cash Equivalents
            </h3>
          </div>
          <div className="text-right text-xs font-mono text-slate-400">
            <div>Close Period: {period}</div>
            <div className="text-emerald-400">Audit Status: Complete ($0.00 Variance)</div>
          </div>
        </div>

        {/* Tabular Tie-Out Breakdown Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-mono text-[11px]">
                <th className="py-2.5 px-3 text-left">Bank Account / Entity</th>
                <th className="py-2.5 px-3 text-right">Bank Statement Balance</th>
                <th className="py-2.5 px-3 text-right">(+) Deposits In Transit</th>
                <th className="py-2.5 px-3 text-right">(-) Outstanding Checks</th>
                <th className="py-2.5 px-3 text-right">(=) Adjusted Cash</th>
                <th className="py-2.5 px-3 text-right">GL Ledger Balance</th>
                <th className="py-2.5 px-3 text-right">Variance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {bankAccounts.map(acc => (
                <tr key={acc.id} className="hover:bg-slate-850/40">
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-200">
                    {acc.name}
                    <span className="block text-[10px] text-slate-500 font-mono">{acc.accountNumber}</span>
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-200 tabular-nums">
                    {formatCurrency(acc.statementEndingBalance)}
                  </td>
                  <td className="py-2.5 px-3 text-right text-emerald-400 tabular-nums">
                    +{formatCurrency(acc.depositsInTransit)}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-400 tabular-nums">
                    -{formatCurrency(acc.outstandingChecks)}
                  </td>
                  <td className="py-2.5 px-3 text-right text-indigo-300 font-semibold tabular-nums">
                    {formatCurrency(acc.adjustedBankBalance)}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-200 tabular-nums">
                    {formatCurrency(acc.glEndingBalance)}
                  </td>
                  <td className="py-2.5 px-3 text-right text-emerald-400 font-bold tabular-nums">
                    {formatCurrency(acc.variance)}
                  </td>
                </tr>
              ))}
              {/* Total Row */}
              <tr className="border-t-2 border-slate-700 bg-slate-950/60 font-bold text-white">
                <td className="py-3 px-3 font-sans">Total Consolidated Cash</td>
                <td className="py-3 px-3 text-right tabular-nums">{formatCurrency(totalStatementBalance)}</td>
                <td className="py-3 px-3 text-right text-emerald-400 tabular-nums">+{formatCurrency(totalDepositsInTransit)}</td>
                <td className="py-3 px-3 text-right text-slate-400 tabular-nums">-{formatCurrency(totalOutstandingChecks)}</td>
                <td className="py-3 px-3 text-right text-indigo-300 tabular-nums">{formatCurrency(adjustedBalance)}</td>
                <td className="py-3 px-3 text-right tabular-nums">{formatCurrency(totalGlBalance)}</td>
                <td className="py-3 px-3 text-right text-emerald-400 tabular-nums">{formatCurrency(variance)}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Audit Sign-Off Signatures Box */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-slate-800 text-xs font-mono">
          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800">
            <span className="text-slate-500 block text-[10px] uppercase">1. Reconciled & Prepared By</span>
            <div className="text-slate-200 font-sans font-semibold mt-1">Marcus Vance, CPA</div>
            <div className="text-slate-400 text-[11px]">Senior Staff Accountant</div>
            <div className="text-emerald-400 text-[10px] mt-2">✓ Verified 2026-10-01 16:42:00</div>
          </div>

          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800">
            <span className="text-slate-500 block text-[10px] uppercase">2. Reviewed & Approved By</span>
            <div className="text-slate-200 font-sans font-semibold mt-1">Sarah Lin, CPA</div>
            <div className="text-slate-400 text-[11px]">Corporate Controller</div>
            <div className="text-emerald-400 text-[10px] mt-2">✓ Approved 2026-10-02 14:20:00</div>
          </div>

          <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800">
            <span className="text-slate-500 block text-[10px] uppercase">3. Final Certification</span>
            <div className="text-slate-200 font-sans font-semibold mt-1">Katherine Thorne</div>
            <div className="text-slate-400 text-[11px]">Chief Financial Officer</div>
            <div className="text-indigo-400 text-[10px] mt-2">
              {isPeriodLocked ? '✓ Period Certified & Hard Locked' : 'Pending Hard Lock Execution'}
            </div>
          </div>
        </div>
      </div>

      {/* Immutable Audit Log Table */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/80">
          <div>
            <h3 className="text-sm font-semibold text-white">Immutable SOX Audit Trail</h3>
            <span className="text-xs text-slate-400">{filteredLogs.length} audit trail events recorded</span>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search user, action, IP..."
              value={logSearch}
              onChange={(e) => setLogSearch(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 w-52"
            />
          </div>
        </div>

        <div className="divide-y divide-slate-800/80 overflow-y-auto max-h-[380px] font-mono text-xs">
          {filteredLogs.map(log => (
            <div key={log.id} className="p-3.5 hover:bg-slate-850/40 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div className="flex items-center gap-2 text-[11px] text-slate-400">
                  <span>{log.timestamp}</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-indigo-300">{log.user}</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-slate-500">{log.role}</span>
                </div>
                <div className="text-slate-200 font-sans mt-0.5">
                  {log.details}
                </div>
              </div>

              <div className="shrink-0 flex items-center gap-2 self-end sm:self-center">
                <span className="text-[10px] text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                  {log.action}
                </span>
                <span className="text-[10px] text-slate-500">
                  IP: {log.ipAddress}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
