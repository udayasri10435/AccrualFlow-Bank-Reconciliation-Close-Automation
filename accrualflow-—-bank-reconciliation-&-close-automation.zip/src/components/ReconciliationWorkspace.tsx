import React, { useState, useMemo } from 'react';
import { 
  BankTransaction, 
  GlTransaction, 
  BankAccountSummary, 
  MatchStatus,
  ErpSource 
} from '../types';
import { 
  Search, 
  Filter, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  Link2, 
  Unlink, 
  ArrowRight,
  PlusCircle,
  FileSpreadsheet,
  ChevronRight,
  ExternalLink,
  ShieldAlert,
  SlidersHorizontal
} from 'lucide-react';

interface ReconciliationWorkspaceProps {
  bankTransactions: BankTransaction[];
  glTransactions: GlTransaction[];
  bankAccounts: BankAccountSummary[];
  selectedAccountId: string;
  onSelectAccount: (id: string) => void;
  onMatchTransactions: (bankId: string, glIds: string[], notes?: string) => void;
  onUnmatchTransaction: (bankId: string) => void;
  onOpenAdjustModal: (bankTx: BankTransaction, initialDifference?: number) => void;
  isPeriodLocked: boolean;
}

export const ReconciliationWorkspace: React.FC<ReconciliationWorkspaceProps> = ({
  bankTransactions,
  glTransactions,
  bankAccounts,
  selectedAccountId,
  onSelectAccount,
  onMatchTransactions,
  onUnmatchTransaction,
  onOpenAdjustModal,
  isPeriodLocked,
}) => {
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedBankId, setSelectedBankId] = useState<string | null>(null);
  const [selectedGlIds, setSelectedGlIds] = useState<string[]>([]);
  const [erpFilter, setErpFilter] = useState<string>('all');

  // Filter transactions for current account
  const currentBankTxs = useMemo(() => {
    return bankTransactions.filter(tx => {
      if (tx.bankAccount !== selectedAccountId) return false;
      if (filterStatus === 'unmatched' && tx.status !== 'unmatched' && tx.status !== 'suggested') return false;
      if (filterStatus === 'suggested' && tx.status !== 'suggested') return false;
      if (filterStatus === 'matched' && tx.status !== 'matched') return false;
      if (filterStatus === 'flagged' && tx.status !== 'flagged') return false;

      if (searchTerm) {
        const query = searchTerm.toLowerCase();
        const matchesDesc = tx.description.toLowerCase().includes(query);
        const matchesAmount = tx.amount.toString().includes(query);
        const matchesCheck = tx.checkNo?.toLowerCase().includes(query);
        const matchesCategory = tx.category.toLowerCase().includes(query);
        return matchesDesc || matchesAmount || matchesCheck || matchesCategory;
      }
      return true;
    });
  }, [bankTransactions, selectedAccountId, filterStatus, searchTerm]);

  // GL transactions filtering
  const currentGlTxs = useMemo(() => {
    return glTransactions.filter(gl => {
      if (erpFilter !== 'all' && gl.sourceErp !== erpFilter) return false;
      if (filterStatus === 'unmatched' && gl.status === 'matched') return false;
      if (filterStatus === 'matched' && gl.status !== 'matched') return false;

      if (searchTerm) {
        const query = searchTerm.toLowerCase();
        const matchesPayee = gl.payeeOrCustomer.toLowerCase().includes(query);
        const matchesDoc = gl.docNumber.toLowerCase().includes(query);
        const matchesAccount = gl.accountName.toLowerCase().includes(query) || gl.accountCode.includes(query);
        const matchesAmount = gl.amount.toString().includes(query);
        return matchesPayee || matchesDoc || matchesAccount || matchesAmount;
      }
      return true;
    });
  }, [glTransactions, erpFilter, filterStatus, searchTerm]);

  // Calculations for active manual match selection
  const activeBankTx = bankTransactions.find(t => t.id === selectedBankId);
  const activeGlTxs = glTransactions.filter(g => selectedGlIds.includes(g.id));

  const totalSelectedBankAmount = activeBankTx ? activeBankTx.amount : 0;
  const totalSelectedGlAmount = activeGlTxs.reduce((sum, g) => sum + g.amount, 0);
  const selectionDifference = Math.abs(totalSelectedBankAmount) - Math.abs(totalSelectedGlAmount);
  const isExactTieOut = Math.abs(selectionDifference) < 0.01 && activeBankTx && activeGlTxs.length > 0;

  const handleBankSelect = (tx: BankTransaction) => {
    if (selectedBankId === tx.id) {
      setSelectedBankId(null);
      setSelectedGlIds([]);
    } else {
      setSelectedBankId(tx.id);
      // Auto-suggest GL items if suggested
      if (tx.status === 'suggested' && tx.matchedGlIds.length > 0) {
        setSelectedGlIds(tx.matchedGlIds);
      } else {
        // Find possible exact match by absolute amount
        const candidate = glTransactions.find(g => 
          g.status === 'unreconciled' && Math.abs(Math.abs(g.amount) - Math.abs(tx.amount)) < 0.01
        );
        if (candidate) {
          setSelectedGlIds([candidate.id]);
        } else {
          setSelectedGlIds([]);
        }
      }
    }
  };

  const handleGlToggle = (gl: GlTransaction) => {
    if (selectedGlIds.includes(gl.id)) {
      setSelectedGlIds(selectedGlIds.filter(id => id !== gl.id));
    } else {
      setSelectedGlIds([...selectedGlIds, gl.id]);
    }
  };

  const executeMatch = () => {
    if (!selectedBankId || selectedGlIds.length === 0) return;
    onMatchTransactions(selectedBankId, selectedGlIds);
    setSelectedBankId(null);
    setSelectedGlIds([]);
  };

  const formatCurrency = (val: number) => {
    const isNeg = val < 0;
    const formatted = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(Math.abs(val));
    return isNeg ? `(${formatted})` : formatted;
  };

  return (
    <div className="space-y-4">
      {/* Top Filter and Account Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 sm:p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        
        {/* Account Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
          {bankAccounts.map(account => {
            const isSelected = account.id === selectedAccountId;
            return (
              <button
                key={account.id}
                onClick={() => {
                  onSelectAccount(account.id);
                  setSelectedBankId(null);
                  setSelectedGlIds([]);
                }}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap flex items-center gap-2 border ${
                  isSelected
                    ? 'bg-slate-800 border-indigo-500/50 text-white shadow-sm'
                    : 'bg-slate-900/40 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-850'
                }`}
              >
                <span>{account.name}</span>
                <span className="font-mono text-[11px] text-slate-400">
                  {formatCurrency(account.statementEndingBalance)}
                </span>
              </button>
            );
          })}
        </div>

        {/* Search & Status Filter Controls */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search memo, ref, amount..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 w-44 sm:w-56"
            />
          </div>

          {/* Status Segmented Buttons */}
          <div className="flex items-center p-0.5 bg-slate-950 border border-slate-800 rounded-lg">
            {['all', 'unmatched', 'suggested', 'matched', 'flagged'].map((status) => (
              <button
                key={status}
                onClick={() => setFilterStatus(status)}
                className={`px-2.5 py-1 text-xs capitalize font-medium rounded transition-colors whitespace-nowrap ${
                  filterStatus === status
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

      </div>

      {/* Interactive Match Action Bar (when bank or GL item selected) */}
      {(selectedBankId || selectedGlIds.length > 0) && (
        <div className="bg-slate-850 border border-indigo-500/40 rounded-xl p-3 sm:p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-lg shadow-indigo-950/40 transition-all animate-in fade-in duration-200">
          <div className="flex items-center gap-3 text-xs flex-wrap">
            <span className="text-indigo-300 font-semibold flex items-center gap-1.5">
              <Link2 className="w-4 h-4 text-indigo-400" />
              Reconciliation Pairing
            </span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="text-slate-300">
              Bank: <strong className="font-mono text-white tabular-nums">{activeBankTx ? formatCurrency(activeBankTx.amount) : '$0.00'}</strong>
            </span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="text-slate-300">
              GL ({selectedGlIds.length} items): <strong className="font-mono text-white tabular-nums">{formatCurrency(totalSelectedGlAmount)}</strong>
            </span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className={`font-mono tabular-nums ${isExactTieOut ? 'text-emerald-400 font-semibold' : 'text-amber-400'}`}>
              Variance: {formatCurrency(selectionDifference)}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setSelectedBankId(null);
                setSelectedGlIds([]);
              }}
              className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white transition-colors"
            >
              Clear Selection
            </button>

            {isExactTieOut ? (
              <button
                onClick={executeMatch}
                disabled={isPeriodLocked}
                className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm flex items-center gap-1.5 transition-all"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                Confirm Match ($0.00 Variance)
              </button>
            ) : (
              <button
                onClick={() => {
                  if (activeBankTx) {
                    onOpenAdjustModal(activeBankTx, selectionDifference);
                  }
                }}
                disabled={isPeriodLocked || !activeBankTx}
                className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm flex items-center gap-1.5 transition-all"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                Create Adjusting Entry & Match
              </button>
            )}
          </div>
        </div>
      )}

      {/* Split Pane: Bank Feed on Left vs General Ledger on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* Left Pane: Bank Statement Feed */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl overflow-hidden flex flex-col">
          <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-slate-200">Bank Statement Feed</span>
              <span className="text-xs text-slate-500">·</span>
              <span className="text-xs text-slate-400">{currentBankTxs.length} items</span>
            </div>
            <div className="text-xs text-slate-400 flex items-center gap-1.5">
              <span>Cleared per statement</span>
            </div>
          </div>

          <div className="divide-y divide-slate-800/80 overflow-y-auto max-h-[560px]">
            {currentBankTxs.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                No bank transactions found matching filter criteria.
              </div>
            ) : (
              currentBankTxs.map((tx) => {
                const isSelected = selectedBankId === tx.id;
                const isCredit = tx.amount > 0;
                
                return (
                  <div
                    key={tx.id}
                    onClick={() => handleBankSelect(tx)}
                    className={`p-3 text-xs transition-colors cursor-pointer flex flex-col gap-1.5 ${
                      isSelected
                        ? 'bg-indigo-950/40 border-l-2 border-indigo-400'
                        : tx.status === 'matched'
                        ? 'bg-slate-900/20 hover:bg-slate-850/40 text-slate-400'
                        : tx.status === 'flagged'
                        ? 'bg-amber-950/10 hover:bg-amber-950/20 border-l-2 border-amber-500/50'
                        : 'hover:bg-slate-850/60'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-2 font-mono text-[11px] text-slate-400">
                        <span>{tx.date}</span>
                        {tx.checkNo && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>Chk #{tx.checkNo}</span>
                          </>
                        )}
                        <span aria-hidden="true">·</span>
                        <span className="text-slate-500">{tx.category}</span>
                      </div>

                      <div className={`font-mono tabular-nums text-sm font-semibold shrink-0 ${
                        isCredit ? 'text-emerald-400' : 'text-slate-200'
                      }`}>
                        {formatCurrency(tx.amount)}
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <div className="font-medium text-slate-200 truncate pr-2">
                        {tx.description}
                      </div>

                      {/* Status Indicators (Unboxed, clean typographic) */}
                      <div className="shrink-0 flex items-center gap-2">
                        {tx.status === 'matched' && (
                          <div className="flex items-center gap-1.5 text-[11px] text-emerald-400">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Matched</span>
                            {!isPeriodLocked && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onUnmatchTransaction(tx.id);
                                }}
                                className="text-slate-500 hover:text-rose-400 ml-1 transition-colors"
                                title="Unmatch transaction"
                              >
                                <Unlink className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        )}

                        {tx.status === 'suggested' && (
                          <div className="flex items-center gap-1 text-[11px] text-indigo-400 font-medium">
                            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                            <span>Suggested {tx.confidence}%</span>
                          </div>
                        )}

                        {tx.status === 'flagged' && (
                          <div className="flex items-center gap-1 text-[11px] text-amber-400 font-medium">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            <span>Flagged Anomaly</span>
                          </div>
                        )}

                        {tx.status === 'unmatched' && (
                          <span className="text-[11px] text-slate-400 font-mono">Unmatched</span>
                        )}
                      </div>
                    </div>

                    {tx.notes && (
                      <div className="text-[11px] text-slate-400 italic">
                        {tx.notes}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Pane: ERP General Ledger Records */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl overflow-hidden flex flex-col">
          <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-slate-200">General Ledger (ERP)</span>
              <span className="text-xs text-slate-500">·</span>
              <span className="text-xs text-slate-400">{currentGlTxs.length} records</span>
            </div>

            {/* ERP Source Filter */}
            <div className="flex items-center gap-1 text-xs">
              <span className="text-slate-500 text-[11px]">ERP:</span>
              {['all', 'NetSuite', 'QuickBooks', 'Xero'].map(erp => (
                <button
                  key={erp}
                  onClick={() => setErpFilter(erp)}
                  className={`px-2 py-0.5 text-[11px] rounded transition-colors ${
                    erpFilter === erp
                      ? 'bg-slate-800 text-slate-200 font-medium'
                      : 'text-slate-400 hover:text-slate-300'
                  }`}
                >
                  {erp}
                </button>
              ))}
            </div>
          </div>

          <div className="divide-y divide-slate-800/80 overflow-y-auto max-h-[560px]">
            {currentGlTxs.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                No GL records found matching current criteria.
              </div>
            ) : (
              currentGlTxs.map((gl) => {
                const isSelected = selectedGlIds.includes(gl.id);
                const isCredit = gl.amount > 0;

                return (
                  <div
                    key={gl.id}
                    onClick={() => handleGlToggle(gl)}
                    className={`p-3 text-xs transition-colors cursor-pointer flex flex-col gap-1.5 ${
                      isSelected
                        ? 'bg-indigo-950/40 border-l-2 border-indigo-400'
                        : gl.status === 'matched'
                        ? 'bg-slate-900/20 hover:bg-slate-850/40 text-slate-400'
                        : 'hover:bg-slate-850/60'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-2 font-mono text-[11px] text-slate-400">
                        <span>{gl.date}</span>
                        <span aria-hidden="true">·</span>
                        <span className="text-indigo-300">{gl.docNumber}</span>
                        <span aria-hidden="true">·</span>
                        <span className="text-slate-500">{gl.accountCode} - {gl.accountName}</span>
                      </div>

                      <div className={`font-mono tabular-nums text-sm font-semibold shrink-0 ${
                        isCredit ? 'text-emerald-400' : 'text-slate-200'
                      }`}>
                        {formatCurrency(gl.amount)}
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <div className="font-medium text-slate-200 truncate pr-2">
                        {gl.payeeOrCustomer}
                        <span className="ml-2 font-normal text-slate-400 text-[11px]">{gl.memo}</span>
                      </div>

                      <div className="shrink-0 flex items-center gap-2">
                        <span className="text-[10px] text-slate-400 font-mono">
                          {gl.sourceErp}
                        </span>

                        {gl.status === 'matched' ? (
                          <div className="flex items-center gap-1 text-[11px] text-emerald-400">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Matched</span>
                          </div>
                        ) : (
                          <span className="text-[11px] text-slate-400 font-mono">Open</span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
