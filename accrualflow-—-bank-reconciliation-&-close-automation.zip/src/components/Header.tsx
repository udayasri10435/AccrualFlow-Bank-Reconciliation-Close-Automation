import React from 'react';
import { 
  Building2, 
  Sparkles, 
  Lock, 
  RefreshCw, 
  CheckCircle2, 
  ShieldCheck,
  ChevronDown
} from 'lucide-react';
import { ErpSource } from '../types';

interface HeaderProps {
  activeTab: 'reconciliation' | 'anomalies' | 'close' | 'integrations' | 'binder';
  setActiveTab: (tab: 'reconciliation' | 'anomalies' | 'close' | 'integrations' | 'binder') => void;
  selectedAccount: string;
  setSelectedAccount: (accId: string) => void;
  isPeriodLocked: boolean;
  onLockPeriodToggle: () => void;
  onRunAutoMatch: () => void;
  isMatching: boolean;
  unresolvedAnomaliesCount: number;
  period: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  selectedAccount,
  setSelectedAccount,
  isPeriodLocked,
  onLockPeriodToggle,
  onRunAutoMatch,
  isMatching,
  unresolvedAnomaliesCount,
  period,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Strictly compliant Top Bar Contract: Zone 1 (Wordmark), Zone 2 (Nav links), Zone 3 (Primary Actions) */}
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Zone 1: Single element brand wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-bold text-base shadow-sm">
              AF
            </div>
            <a href="#" className="text-lg font-semibold tracking-tight text-white hover:text-indigo-300 transition-colors">
              AccrualFlow
            </a>
          </div>

          {/* Zone 2: 4-6 clean text navigation links with subtle active states */}
          <nav className="hidden md:flex items-center gap-1 sm:gap-2">
            <button
              onClick={() => setActiveTab('reconciliation')}
              className={`px-3 py-2 text-xs sm:text-sm font-medium transition-colors border-b-2 whitespace-nowrap ${
                activeTab === 'reconciliation'
                  ? 'border-indigo-400 text-white font-semibold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Reconciliation
            </button>

            <button
              onClick={() => setActiveTab('anomalies')}
              className={`relative px-3 py-2 text-xs sm:text-sm font-medium transition-colors border-b-2 whitespace-nowrap ${
                activeTab === 'anomalies'
                  ? 'border-indigo-400 text-white font-semibold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Risk & Anomalies
              {unresolvedAnomaliesCount > 0 && (
                <span className="ml-1.5 px-1.5 py-0.2 text-[10px] font-mono bg-amber-500/20 text-amber-300 rounded border border-amber-500/30">
                  {unresolvedAnomaliesCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('close')}
              className={`px-3 py-2 text-xs sm:text-sm font-medium transition-colors border-b-2 whitespace-nowrap ${
                activeTab === 'close'
                  ? 'border-indigo-400 text-white font-semibold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Close Checklist
            </button>

            <button
              onClick={() => setActiveTab('integrations')}
              className={`px-3 py-2 text-xs sm:text-sm font-medium transition-colors border-b-2 whitespace-nowrap ${
                activeTab === 'integrations'
                  ? 'border-indigo-400 text-white font-semibold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              ERP Feeds & Rules
            </button>

            <button
              onClick={() => setActiveTab('binder')}
              className={`px-3 py-2 text-xs sm:text-sm font-medium transition-colors border-b-2 whitespace-nowrap ${
                activeTab === 'binder'
                  ? 'border-indigo-400 text-white font-semibold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Audit Binder
            </button>
          </nav>

          {/* Zone 3: 1-2 primary functional actions */}
          <div className="flex items-center gap-3">
            {/* Auto-Match Trigger */}
            <button
              onClick={onRunAutoMatch}
              disabled={isMatching || isPeriodLocked}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 whitespace-nowrap ${
                isPeriodLocked
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm shadow-indigo-950 active:scale-[0.98]'
              }`}
              title={isPeriodLocked ? "Period locked: matching disabled" : "Run automated matching rules across bank and GL"}
            >
              <Sparkles className={`w-3.5 h-3.5 ${isMatching ? 'animate-spin' : ''}`} />
              <span>{isMatching ? 'Matching...' : 'Auto-Match'}</span>
            </button>

            {/* Lock / Unlock Period Toggle */}
            <button
              onClick={onLockPeriodToggle}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 border whitespace-nowrap ${
                isPeriodLocked
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-300 hover:bg-amber-500/20'
                  : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700 hover:text-white'
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{isPeriodLocked ? 'Period Locked' : 'Lock Period'}</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
