import React, { useState } from 'react';
import { ErpConnection, ReconciliationRule } from '../types';
import { 
  Building2, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  Plus, 
  Settings2, 
  Sliders, 
  Sparkles,
  Layers,
  ArrowRight,
  Database
} from 'lucide-react';

interface IntegrationsManagerProps {
  erpConnections: ErpConnection[];
  rules: ReconciliationRule[];
  onSyncPlatform: (platform: string) => Promise<void>;
  onToggleRule: (ruleId: string) => void;
  onAddRule: (rule: Omit<ReconciliationRule, 'id' | 'hitsCount'>) => void;
  isSyncing: boolean;
}

export const IntegrationsManager: React.FC<IntegrationsManagerProps> = ({
  erpConnections,
  rules,
  onSyncPlatform,
  onToggleRule,
  onAddRule,
  isSyncing,
}) => {
  const [showAddRuleModal, setShowAddRuleModal] = useState<boolean>(false);
  const [newRuleName, setNewRuleName] = useState<string>('');
  const [newVendorCondition, setNewVendorCondition] = useState<string>('');
  const [newAccountCode, setNewAccountCode] = useState<string>('6050');
  const [newAccountName, setNewAccountName] = useState<string>('Software Subscriptions');
  const [newMatchType, setNewMatchType] = useState<'exact' | 'fuzzy' | 'tolerance'>('fuzzy');
  const [newAutoApprove, setNewAutoApprove] = useState<boolean>(true);

  const handleCreateRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRuleName || !newVendorCondition) return;

    onAddRule({
      name: newRuleName,
      conditionVendor: newVendorCondition,
      targetAccount: newAccountName,
      targetAccountCode: newAccountCode,
      matchType: newMatchType,
      autoApprove: newAutoApprove,
      enabled: true,
      notes: `Custom user rule for ${newVendorCondition}`,
    });

    setNewRuleName('');
    setNewVendorCondition('');
    setShowAddRuleModal(false);
  };

  return (
    <div className="space-y-6">
      
      {/* ERP Connections Grid: QuickBooks, Xero, NetSuite */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-base font-bold text-white">
              Connected Accounting ERP Ledgers
            </h2>
            <p className="text-xs text-slate-400">
              Live bidirectional feeds for General Ledger journals, subledgers, and banking webhooks
            </p>
          </div>

          <button
            onClick={() => onSyncPlatform('all')}
            disabled={isSyncing}
            className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm flex items-center gap-1.5 transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Syncing All ERPs...' : 'Sync All Feeds'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {erpConnections.map(conn => {
            return (
              <div 
                key={conn.id}
                className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded bg-indigo-950/60 border border-indigo-500/30 flex items-center justify-center font-bold text-xs text-indigo-300">
                        {conn.name[0]}
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white">{conn.name}</h3>
                        <span className="text-[11px] text-slate-400 block truncate max-w-[180px]">
                          {conn.companyName}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 text-[11px] text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{conn.health}</span>
                    </div>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-400 bg-slate-950/60 border border-slate-800/80 rounded-lg p-3 my-3 font-mono">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Last Synced:</span>
                      <span className="text-slate-200">{conn.lastSync}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">GL Accounts:</span>
                      <span className="text-slate-200">{conn.accountCount} active</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Token Health:</span>
                      <span className="text-indigo-300">{conn.tokenExpiresIn}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                  <span className="text-[11px] text-slate-500 font-mono truncate max-w-[150px]">
                    {conn.authMethod}
                  </span>
                  <button
                    onClick={() => onSyncPlatform(conn.name)}
                    disabled={isSyncing}
                    className="px-2.5 py-1 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors flex items-center gap-1"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Sync</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Automated Matching Rules Engine */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
          <div>
            <h3 className="text-sm font-semibold text-white">
              Automated Reconciliation Rules Engine
            </h3>
            <p className="text-xs text-slate-400">
              Deterministic & fuzzy matching heuristics for recurring vendors, payroll batches, and processor settlements
            </p>
          </div>

          <button
            onClick={() => setShowAddRuleModal(true)}
            className="px-3 py-1.5 rounded-lg text-xs font-medium bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Rule</span>
          </button>
        </div>

        <div className="divide-y divide-slate-800/80">
          {rules.map(rule => {
            return (
              <div 
                key={rule.id}
                className="p-4 text-xs flex flex-col md:flex-row md:items-center justify-between gap-3 hover:bg-slate-850/40 transition-colors"
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="text-sm font-semibold text-white">{rule.name}</h4>
                    <span className="font-mono text-[10px] text-indigo-300 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-500/20 uppercase">
                      {rule.matchType} Match
                    </span>
                    {rule.autoApprove && (
                      <span className="font-mono text-[10px] text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-500/20">
                        Auto-Approve
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <span>When Memo contains: <strong className="text-slate-200 font-mono">"{rule.conditionVendor}"</strong></span>
                    <span aria-hidden="true">·</span>
                    <span>Target: <strong className="text-slate-200">{rule.targetAccountCode} - {rule.targetAccount}</strong></span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono text-slate-500">{rule.hitsCount} matched to date</span>
                  </div>

                  <div className="text-[11px] text-slate-400 mt-1 italic">
                    {rule.notes}
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0 self-end md:self-center">
                  <span className={`text-[11px] font-mono ${rule.enabled ? 'text-emerald-400' : 'text-slate-500'}`}>
                    {rule.enabled ? 'Active' : 'Disabled'}
                  </span>

                  <button
                    onClick={() => onToggleRule(rule.id)}
                    className={`px-3 py-1 rounded text-xs font-medium border transition-colors ${
                      rule.enabled
                        ? 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
                        : 'border-indigo-500/30 bg-indigo-950/40 text-indigo-300 hover:bg-indigo-900/60'
                    }`}
                  >
                    {rule.enabled ? 'Disable' : 'Enable'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Rule Modal */}
      {showAddRuleModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Create Reconciliation Rule</h3>
              <button 
                onClick={() => setShowAddRuleModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateRule} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Rule Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. GitHub Copilot Subscriptions"
                  value={newRuleName}
                  onChange={(e) => setNewRuleName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Bank Description Contains (Keyword)
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. GITHUB INC"
                  value={newVendorCondition}
                  onChange={(e) => setNewVendorCondition(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Account Code</label>
                  <input
                    type="text"
                    value={newAccountCode}
                    onChange={(e) => setNewAccountCode(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Account Name</label>
                  <input
                    type="text"
                    value={newAccountName}
                    onChange={(e) => setNewAccountName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Match Type</label>
                  <select
                    value={newMatchType}
                    onChange={(e) => setNewMatchType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="exact">Exact Amount & Reference</option>
                    <option value="fuzzy">Fuzzy Date & Payee</option>
                    <option value="tolerance">Fee Tolerance ($0-$500)</option>
                  </select>
                </div>

                <div className="flex items-center pt-5">
                  <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                    <input
                      type="checkbox"
                      checked={newAutoApprove}
                      onChange={(e) => setNewAutoApprove(e.target.checked)}
                      className="rounded bg-slate-950 border-slate-800 text-indigo-600 focus:ring-0"
                    />
                    <span>Auto-Approve Match</span>
                  </label>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddRuleModal(false)}
                  className="px-4 py-2 text-slate-300 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold"
                >
                  Save Rule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
