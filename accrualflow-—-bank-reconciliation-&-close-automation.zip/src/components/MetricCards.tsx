import React from 'react';
import { 
  CheckCircle2, 
  AlertCircle, 
  Layers, 
  TrendingUp, 
  Building,
  ShieldAlert
} from 'lucide-react';
import { BankAccountSummary } from '../types';

interface MetricCardsProps {
  currentAccount: BankAccountSummary;
  matchedCount: number;
  totalTransactionsCount: number;
  unresolvedAnomaliesCount: number;
  closeMilestonesCompleted: number;
  closeMilestonesTotal: number;
  isPeriodLocked: boolean;
}

export const MetricCards: React.FC<MetricCardsProps> = ({
  currentAccount,
  matchedCount,
  totalTransactionsCount,
  unresolvedAnomaliesCount,
  closeMilestonesCompleted,
  closeMilestonesTotal,
  isPeriodLocked,
}) => {
  const matchRate = totalTransactionsCount > 0 
    ? Math.round((matchedCount / totalTransactionsCount) * 100) 
    : 100;

  const isBalanced = Math.abs(currentAccount.variance) < 0.01;

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(val);
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6">
      
      {/* Card 1: Bank Statement vs General Ledger */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
          <span>Statement vs Ledger</span>
          <span className="font-mono text-slate-500">{currentAccount.accountNumber}</span>
        </div>
        <div className="text-xl sm:text-2xl font-bold text-white font-mono tabular-nums mb-2">
          {formatCurrency(currentAccount.statementEndingBalance)}
        </div>
        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          <span>GL Book</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono text-slate-300 tabular-nums">
            {formatCurrency(currentAccount.glEndingBalance)}
          </span>
          <span aria-hidden="true">·</span>
          <span className="text-emerald-400">Active Feed</span>
        </div>
      </div>

      {/* Card 2: Tie-Out Variance ($0.00 target) */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
          <span>Reconciliation Variance</span>
          <span className={`text-[11px] font-medium ${isBalanced ? 'text-emerald-400' : 'text-amber-400'}`}>
            {isBalanced ? 'Balanced' : 'Requires Adjustment'}
          </span>
        </div>
        <div className={`text-xl sm:text-2xl font-bold font-mono tabular-nums mb-2 ${
          isBalanced ? 'text-emerald-400' : 'text-amber-400'
        }`}>
          {formatCurrency(currentAccount.variance)}
        </div>
        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          <span>Deposits in Transit</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono text-slate-300 tabular-nums">{formatCurrency(currentAccount.depositsInTransit)}</span>
        </div>
      </div>

      {/* Card 3: Match Throughput Rate */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
          <span>Matching Efficiency</span>
          <span className="font-mono text-slate-400 tabular-nums">{matchedCount}/{totalTransactionsCount}</span>
        </div>
        <div className="text-xl sm:text-2xl font-bold text-white font-mono tabular-nums mb-2">
          {matchRate}%
        </div>
        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          <span>Exact & Fuzzy Rules</span>
          <span aria-hidden="true">·</span>
          <span className="text-indigo-400">NetSuite & QBO synced</span>
        </div>
      </div>

      {/* Card 4: Month-End Close Readiness */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
          <span>Period Close Readiness</span>
          <span className="font-mono text-slate-400 tabular-nums">
            {closeMilestonesCompleted}/{closeMilestonesTotal}
          </span>
        </div>
        <div className="text-xl sm:text-2xl font-bold text-white font-mono tabular-nums mb-2">
          {Math.round((closeMilestonesCompleted / closeMilestonesTotal) * 100)}%
        </div>
        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          <span>Dual Sign-Off</span>
          <span aria-hidden="true">·</span>
          <span className={isPeriodLocked ? 'text-amber-400' : 'text-slate-300'}>
            {isPeriodLocked ? 'Hard Lock Active' : 'Pre-Close Phase'}
          </span>
        </div>
      </div>

    </div>
  );
};
