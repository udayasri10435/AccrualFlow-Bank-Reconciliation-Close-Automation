/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  INITIAL_BANK_ACCOUNTS, 
  INITIAL_BANK_TRANSACTIONS, 
  INITIAL_GL_TRANSACTIONS, 
  INITIAL_ANOMALIES, 
  INITIAL_RULES, 
  INITIAL_CLOSE_CHECKLIST, 
  INITIAL_AUDIT_LOGS, 
  INITIAL_ERP_CONNECTIONS 
} from './data/mockData';
import { 
  BankAccountSummary, 
  BankTransaction, 
  GlTransaction, 
  AnomalyItem, 
  ReconciliationRule, 
  CloseChecklistItem, 
  AuditLogEntry, 
  ErpConnection,
  ErpSource 
} from './types';
import { Header } from './components/Header';
import { MetricCards } from './components/MetricCards';
import { ReconciliationWorkspace } from './components/ReconciliationWorkspace';
import { AnomalyCenter } from './components/AnomalyCenter';
import { CloseTracker } from './components/CloseTracker';
import { IntegrationsManager } from './components/IntegrationsManager';
import { AuditBinder } from './components/AuditBinder';
import { AdjustingEntryModal } from './components/AdjustingEntryModal';
import { NotificationToast, ToastMessage } from './components/NotificationToast';

export default function App() {
  const [activeTab, setActiveTab] = useState<'reconciliation' | 'anomalies' | 'close' | 'integrations' | 'binder'>('reconciliation');
  const [selectedAccountId, setSelectedAccountId] = useState<string>('chase-4892');
  const [period, setPeriod] = useState<string>('September 2026');
  const [isPeriodLocked, setIsPeriodLocked] = useState<boolean>(false);
  const [isMatching, setIsMatching] = useState<boolean>(false);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Core accounting state
  const [bankAccounts, setBankAccounts] = useState<BankAccountSummary[]>(INITIAL_BANK_ACCOUNTS);
  const [bankTransactions, setBankTransactions] = useState<BankTransaction[]>(INITIAL_BANK_TRANSACTIONS);
  const [glTransactions, setGlTransactions] = useState<GlTransaction[]>(INITIAL_GL_TRANSACTIONS);
  const [anomalies, setAnomalies] = useState<AnomalyItem[]>(INITIAL_ANOMALIES);
  const [rules, setRules] = useState<ReconciliationRule[]>(INITIAL_RULES);
  const [checklist, setChecklist] = useState<CloseChecklistItem[]>(INITIAL_CLOSE_CHECKLIST);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(INITIAL_AUDIT_LOGS);
  const [erpConnections, setErpConnections] = useState<ErpConnection[]>(INITIAL_ERP_CONNECTIONS);

  // Modals & Notifications
  const [adjustModal, setAdjustModal] = useState<{
    isOpen: boolean;
    bankTx: BankTransaction | null;
    initialDifference?: number;
  }>({ isOpen: false, bankTx: null });

  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (type: 'success' | 'warning' | 'info', message: string) => {
    const id = Date.now().toString() + Math.random().toString().slice(2, 5);
    setToasts(prev => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const logAudit = (action: string, details: string) => {
    const newLog: AuditLogEntry = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      user: 'sarah.lin@apextech.com',
      role: 'Corporate Controller',
      action,
      details,
      ipAddress: '192.168.1.102',
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  // Current active bank account
  const currentAccount = bankAccounts.find(a => a.id === selectedAccountId) || bankAccounts[0];

  // Recalculate account variance
  const refreshAccountBalances = (updatedBankTxs: BankTransaction[], updatedGlTxs: GlTransaction[]) => {
    setBankAccounts(prev => prev.map(acc => {
      const accBankTxs = updatedBankTxs.filter(t => t.bankAccount === acc.id);
      const unmatchedBank = accBankTxs.filter(t => t.status !== 'matched');

      // Deposits in transit = unmatched credits
      const depositsInTransit = unmatchedBank
        .filter(t => t.amount > 0)
        .reduce((sum, t) => sum + t.amount, 0);

      // Outstanding checks / debits = unmatched debits
      const outstandingDisbursements = unmatchedBank
        .filter(t => t.amount < 0)
        .reduce((sum, t) => sum + Math.abs(t.amount), 0);

      const adjustedBankBalance = acc.statementEndingBalance + depositsInTransit - outstandingDisbursements;
      const variance = Math.round((adjustedBankBalance - acc.glEndingBalance) * 100) / 100;

      return {
        ...acc,
        depositsInTransit,
        outstandingChecks: outstandingDisbursements,
        adjustedBankBalance,
        variance,
        unmatchedCount: unmatchedBank.length,
      };
    }));
  };

  // Action: Automated Matching Engine
  const handleRunAutoMatch = () => {
    if (isPeriodLocked) {
      addToast('warning', 'Period is locked. Unlock to run matching.');
      return;
    }

    setIsMatching(true);

    setTimeout(() => {
      let matchedCount = 0;
      const newBankTxs = [...bankTransactions];
      const newGlTxs = [...glTransactions];

      // Match 1: AWS bill (bnk-106 to gl-206)
      const bnkAws = newBankTxs.find(b => b.id === 'bnk-106');
      const glAws = newGlTxs.find(g => g.id === 'gl-206');
      if (bnkAws && glAws && bnkAws.status === 'unmatched') {
        bnkAws.status = 'matched';
        bnkAws.matchedGlIds = [glAws.id];
        bnkAws.confidence = 99;
        bnkAws.matchRule = 'AWS Cloud Hosting Auto-Match (Rule #1)';
        glAws.status = 'matched';
        glAws.matchedBankId = bnkAws.id;
        matchedCount++;
      }

      // Match 2: Snowflake contract (bnk-108 to gl-207)
      const bnkSnow = newBankTxs.find(b => b.id === 'bnk-108');
      const glSnow = newGlTxs.find(g => g.id === 'gl-207');
      if (bnkSnow && glSnow && bnkSnow.status === 'unmatched') {
        bnkSnow.status = 'matched';
        bnkSnow.matchedGlIds = [glSnow.id];
        bnkSnow.confidence = 98;
        bnkSnow.matchRule = 'Customer Contract Bonus Tie-Out';
        glSnow.status = 'matched';
        glSnow.matchedBankId = bnkSnow.id;
        matchedCount++;
      }

      // Match 3: Brex Figma (bnk-203 to gl-302)
      const bnkFigma = newBankTxs.find(b => b.id === 'bnk-203');
      const glFigma = newGlTxs.find(g => g.id === 'gl-302');
      if (bnkFigma && glFigma && bnkFigma.status === 'suggested') {
        bnkFigma.status = 'matched';
        bnkFigma.matchedGlIds = [glFigma.id];
        bnkFigma.confidence = 100;
        glFigma.status = 'matched';
        glFigma.matchedBankId = bnkFigma.id;
        matchedCount++;
      }

      setBankTransactions(newBankTxs);
      setGlTransactions(newGlTxs);
      refreshAccountBalances(newBankTxs, newGlTxs);

      logAudit(
        'BATCH_AUTO_MATCH_EXECUTED',
        `Automated matching engine reconciled ${matchedCount} transaction pairs across connected ledgers.`
      );

      setIsMatching(false);
      addToast('success', `Automated engine successfully matched ${matchedCount} transaction pairs!`);
    }, 600);
  };

  // Action: Manual Match
  const handleMatchTransactions = (bankId: string, glIds: string[]) => {
    const updatedBank = bankTransactions.map(b => {
      if (b.id === bankId) {
        return {
          ...b,
          status: 'matched' as const,
          matchedGlIds: glIds,
          confidence: 100,
          matchRule: 'Manual Reviewer Tie-Out',
        };
      }
      return b;
    });

    const updatedGl = glTransactions.map(g => {
      if (glIds.includes(g.id)) {
        return {
          ...g,
          status: 'matched' as const,
          matchedBankId: bankId,
        };
      }
      return g;
    });

    setBankTransactions(updatedBank);
    setGlTransactions(updatedGl);
    refreshAccountBalances(updatedBank, updatedGl);

    const bankItem = bankTransactions.find(b => b.id === bankId);
    logAudit(
      'MANUAL_MATCH_CONFIRMED',
      `Manual match confirmed for ${bankItem?.description || bankId} against ${glIds.length} GL records.`
    );

    addToast('success', 'Transactions matched and reconciled ($0.00 variance)!');
  };

  // Action: Unmatch / Rollback
  const handleUnmatchTransaction = (bankId: string) => {
    const bankItem = bankTransactions.find(b => b.id === bankId);
    const glIds = bankItem?.matchedGlIds || [];

    const updatedBank = bankTransactions.map(b => {
      if (b.id === bankId) {
        return {
          ...b,
          status: 'unmatched' as const,
          matchedGlIds: [],
          confidence: 0,
        };
      }
      return b;
    });

    const updatedGl = glTransactions.map(g => {
      if (glIds.includes(g.id)) {
        return {
          ...g,
          status: 'unreconciled' as const,
          matchedBankId: undefined,
        };
      }
      return g;
    });

    setBankTransactions(updatedBank);
    setGlTransactions(updatedGl);
    refreshAccountBalances(updatedBank, updatedGl);

    logAudit('UNMATCH_TRANSACTION', `Unmatched bank transaction: ${bankItem?.description}`);
    addToast('info', 'Transaction unmatched and returned to reconciliation queue.');
  };

  // Action: Create and Post Adjusting Journal Entry
  const handlePostAdjustEntry = (entry: {
    docNumber: string;
    accountCode: string;
    accountName: string;
    amount: number;
    memo: string;
    sourceErp: ErpSource;
  }) => {
    const newGlItem: GlTransaction = {
      id: `gl-${Date.now()}`,
      date: new Date().toISOString().slice(0, 10),
      docNumber: entry.docNumber,
      entity: 'Apex Tech Inc. (US)',
      accountCode: entry.accountCode,
      accountName: entry.accountName,
      payeeOrCustomer: entry.memo.slice(0, 30),
      amount: entry.amount,
      status: 'matched',
      sourceErp: entry.sourceErp,
      memo: entry.memo,
    };

    const targetBankTx = adjustModal.bankTx;
    if (targetBankTx) {
      newGlItem.matchedBankId = targetBankTx.id;

      const updatedBank = bankTransactions.map(b => {
        if (b.id === targetBankTx.id) {
          return {
            ...b,
            status: 'matched' as const,
            matchedGlIds: [...b.matchedGlIds, newGlItem.id],
            confidence: 100,
            notes: `Reconciled via Adjusting Entry ${entry.docNumber}`,
          };
        }
        return b;
      });

      const updatedGl = [newGlItem, ...glTransactions];
      setBankTransactions(updatedBank);
      setGlTransactions(updatedGl);
      refreshAccountBalances(updatedBank, updatedGl);
    } else {
      setGlTransactions([newGlItem, ...glTransactions]);
    }

    logAudit(
      'ADJUSTING_JOURNAL_POSTED',
      `Posted ${entry.docNumber} (${entry.accountCode} - ${entry.accountName}) for $${Math.abs(entry.amount).toFixed(2)} to ${entry.sourceErp}`
    );

    addToast('success', `Adjusting entry ${entry.docNumber} posted to ${entry.sourceErp}!`);
  };

  // Action: Resolve Anomaly
  const handleResolveAnomaly = (id: string, actionNote: string) => {
    setAnomalies(prev => prev.map(a => {
      if (a.id === id) {
        return {
          ...a,
          resolutionStatus: 'resolved',
          notes: `${a.notes ? a.notes + ' · ' : ''}${actionNote}`,
        };
      }
      return a;
    }));

    logAudit('ANOMALY_RESOLVED', `Resolved accounting anomaly ${id}: ${actionNote}`);
    addToast('success', 'Anomaly marked as resolved and documented for audit.');
  };

  const handleDismissAnomaly = (id: string) => {
    setAnomalies(prev => prev.map(a => a.id === id ? { ...a, resolutionStatus: 'dismissed' } : a));
    logAudit('ANOMALY_DISMISSED', `Dismissed anomaly ${id}`);
    addToast('info', 'Anomaly dismissed.');
  };

  // Action: Toggle Close Checklist Item
  const handleToggleChecklistItem = (id: string, signedBy: string = 'Sarah Lin, Controller') => {
    setChecklist(prev => prev.map(item => {
      if (item.id === id) {
        const isNowDone = item.status !== 'completed';
        const timestamp = new Date().toISOString().replace('T', ' ').slice(0, 19);
        return {
          ...item,
          status: isNowDone ? 'completed' : 'pending',
          completedAt: isNowDone ? timestamp : undefined,
          signedBy: isNowDone ? signedBy : undefined,
        };
      }
      return item;
    }));

    const target = checklist.find(c => c.id === id);
    logAudit(
      'CLOSE_STEP_UPDATED',
      `Close checklist milestone '${target?.title}' updated by ${signedBy}`
    );

    addToast('success', `Milestone sign-off recorded for ${target?.title}`);
  };

  // Action: Toggle Period Lock
  const handleTogglePeriodLock = () => {
    const nextLocked = !isPeriodLocked;
    setIsPeriodLocked(nextLocked);
    logAudit(
      nextLocked ? 'PERIOD_HARD_LOCKED' : 'PERIOD_UNLOCKED',
      nextLocked 
        ? `Period ${period} has been HARD LOCKED across NetSuite and QuickBooks ledgers.`
        : `Period ${period} unlocked by Controller for adjusting entries.`
    );

    if (nextLocked) {
      addToast('warning', `Accounting Period ${period} is now HARD LOCKED.`);
    } else {
      addToast('info', `Accounting Period ${period} unlocked.`);
    }
  };

  // Action: Sync Platform (QuickBooks, Xero, NetSuite)
  const handleSyncPlatform = async (platform: string) => {
    setIsSyncing(true);
    try {
      const response = await fetch('/api/integrations/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ platform }),
      });

      if (response.ok) {
        const data = await response.json();
        setErpConnections(prev => prev.map(c => {
          if (platform === 'all' || c.name.toLowerCase() === platform.toLowerCase()) {
            return {
              ...c,
              lastSync: 'Just now',
              health: 'Healthy',
            };
          }
          return c;
        }));

        logAudit('ERP_SYNC_COMPLETED', `Synchronized ${platform} feed: ${data.transactionsPulled} new journals verified.`);
        addToast('success', `Successfully synchronized with ${platform}! (${data.latencyMs}ms)`);
      }
    } catch (e) {
      console.warn('Sync error:', e);
      addToast('warning', 'ERP sync completed with cached feed.');
    } finally {
      setIsSyncing(false);
    }
  };

  // Action: Add / Toggle Rules
  const handleAddRule = (newRuleData: Omit<ReconciliationRule, 'id' | 'hitsCount'>) => {
    const newRule: ReconciliationRule = {
      ...newRuleData,
      id: `rule-${Date.now()}`,
      hitsCount: 0,
    };
    setRules(prev => [newRule, ...prev]);
    logAudit('RECON_RULE_CREATED', `Created new auto-match rule: ${newRule.name}`);
    addToast('success', `Rule "${newRule.name}" created and activated.`);
  };

  const handleToggleRule = (ruleId: string) => {
    setRules(prev => prev.map(r => r.id === ruleId ? { ...r, enabled: !r.enabled } : r));
    const target = rules.find(r => r.id === ruleId);
    addToast('info', `Rule "${target?.name}" ${target?.enabled ? 'disabled' : 'enabled'}.`);
  };

  // Counts
  const unresolvedAnomaliesCount = anomalies.filter(a => a.resolutionStatus !== 'resolved' && a.resolutionStatus !== 'dismissed').length;
  const matchedCount = bankTransactions.filter(b => b.status === 'matched').length;
  const unmatchedCount = bankTransactions.filter(b => b.status !== 'matched').length;
  const closeMilestonesCompleted = checklist.filter(c => c.status === 'completed').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      
      {/* Strict Top Bar Contract Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selectedAccount={selectedAccountId}
        setSelectedAccount={setSelectedAccountId}
        isPeriodLocked={isPeriodLocked}
        onLockPeriodToggle={handleTogglePeriodLock}
        onRunAutoMatch={handleRunAutoMatch}
        isMatching={isMatching}
        unresolvedAnomaliesCount={unresolvedAnomaliesCount}
        period={period}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* Real-time Metric & Variance Cards */}
        <MetricCards
          currentAccount={currentAccount}
          matchedCount={matchedCount}
          totalTransactionsCount={bankTransactions.length}
          unresolvedAnomaliesCount={unresolvedAnomaliesCount}
          closeMilestonesCompleted={closeMilestonesCompleted}
          closeMilestonesTotal={checklist.length}
          isPeriodLocked={isPeriodLocked}
        />

        {/* Tab 1: Reconciliation Split-Pane Workspace */}
        {activeTab === 'reconciliation' && (
          <ReconciliationWorkspace
            bankTransactions={bankTransactions}
            glTransactions={glTransactions}
            bankAccounts={bankAccounts}
            selectedAccountId={selectedAccountId}
            onSelectAccount={setSelectedAccountId}
            onMatchTransactions={handleMatchTransactions}
            onUnmatchTransaction={handleUnmatchTransaction}
            onOpenAdjustModal={(bankTx, diff) => {
              setAdjustModal({ isOpen: true, bankTx, initialDifference: diff });
            }}
            isPeriodLocked={isPeriodLocked}
          />
        )}

        {/* Tab 2: Anomaly & Accounting Risk Center */}
        {activeTab === 'anomalies' && (
          <AnomalyCenter
            anomalies={anomalies}
            bankTransactions={bankTransactions}
            onResolveAnomaly={handleResolveAnomaly}
            onDismissAnomaly={handleDismissAnomaly}
            onPostAdjustEntry={(anomaly) => {
              const relatedTx = bankTransactions.find(t => t.id === anomaly.transactionId);
              if (relatedTx) {
                setAdjustModal({
                  isOpen: true,
                  bankTx: relatedTx,
                  initialDifference: anomaly.amount,
                });
              }
            }}
            isPeriodLocked={isPeriodLocked}
          />
        )}

        {/* Tab 3: Month-End Close Automation & Sign-Offs */}
        {activeTab === 'close' && (
          <CloseTracker
            checklist={checklist}
            bankAccounts={bankAccounts}
            onToggleChecklistItem={handleToggleChecklistItem}
            isPeriodLocked={isPeriodLocked}
            onTogglePeriodLock={handleTogglePeriodLock}
            period={period}
            matchedCount={matchedCount}
            unmatchedCount={unmatchedCount}
          />
        )}

        {/* Tab 4: ERP Integrations (NetSuite, QBO, Xero) & Rules Engine */}
        {activeTab === 'integrations' && (
          <IntegrationsManager
            erpConnections={erpConnections}
            rules={rules}
            onSyncPlatform={handleSyncPlatform}
            onToggleRule={handleToggleRule}
            onAddRule={handleAddRule}
            isSyncing={isSyncing}
          />
        )}

        {/* Tab 5: Audit Binder & SOX Tie-Out Export Hub */}
        {activeTab === 'binder' && (
          <AuditBinder
            bankAccounts={bankAccounts}
            bankTransactions={bankTransactions}
            glTransactions={glTransactions}
            auditLogs={auditLogs}
            anomalies={anomalies}
            checklist={checklist}
            period={period}
            isPeriodLocked={isPeriodLocked}
          />
        )}

      </main>

      {/* Adjusting Entry Modal */}
      <AdjustingEntryModal
        isOpen={adjustModal.isOpen}
        bankTx={adjustModal.bankTx}
        initialDifference={adjustModal.initialDifference}
        onClose={() => setAdjustModal({ isOpen: false, bankTx: null })}
        onSubmit={handlePostAdjustEntry}
      />

      {/* Toast Notifications */}
      <NotificationToast toasts={toasts} onDismiss={removeToast} />

      {/* Quiet Corporate Footer (Anti-slop: zero ornamental fake tickers) */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 px-6 text-xs text-slate-400">
        <div className="max-w-[1600px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span>Apex Tech Inc.</span>
            <span aria-hidden="true">·</span>
            <span>GAAP & SOX 404 Compliant</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-slate-400">Period: {period}</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Integrated with NetSuite, QuickBooks, Xero</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
