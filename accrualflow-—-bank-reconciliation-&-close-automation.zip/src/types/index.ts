export type MatchStatus = 'unmatched' | 'suggested' | 'matched' | 'flagged';
export type ErpSource = 'NetSuite' | 'QuickBooks' | 'Xero';

export interface BankTransaction {
  id: string;
  date: string;
  description: string;
  amount: number; // Positive = credit/deposit, Negative = debit/withdrawal
  checkNo?: string;
  category: string;
  status: MatchStatus;
  matchedGlIds: string[];
  confidence?: number;
  matchRule?: string;
  bankAccount: string;
  notes?: string;
}

export interface GlTransaction {
  id: string;
  date: string;
  docNumber: string;
  entity: string;
  accountCode: string;
  accountName: string;
  payeeOrCustomer: string;
  amount: number;
  status: 'unreconciled' | 'matched';
  matchedBankId?: string;
  sourceErp: ErpSource;
  memo: string;
}

export type AnomalyType = 
  | 'duplicate' 
  | 'cutoff' 
  | 'fee_slippage' 
  | 'unauthorized' 
  | 'amount_variance' 
  | 'missing_doc';

export type AnomalySeverity = 'high' | 'medium' | 'low';

export interface AnomalyItem {
  id: string;
  transactionId: string;
  bankAccount: string;
  title: string;
  type: AnomalyType;
  severity: AnomalySeverity;
  date: string;
  amount: number;
  description: string;
  resolutionStatus: 'open' | 'investigating' | 'resolved' | 'dismissed';
  notes?: string;
  resolutionAction?: string;
  aiAnalysis?: {
    summary: string;
    rootCauseHypothesis: string;
    gaapImplication: string;
    recommendedAction: string;
    suggestedJournalEntry?: {
      needed: boolean;
      debitAccount: string;
      creditAccount: string;
      amount: number;
      memo: string;
    };
  };
}

export interface ReconciliationRule {
  id: string;
  name: string;
  conditionVendor: string;
  targetAccount: string;
  targetAccountCode: string;
  matchType: 'exact' | 'fuzzy' | 'tolerance';
  autoApprove: boolean;
  hitsCount: number;
  enabled: boolean;
  notes: string;
}

export interface CloseChecklistItem {
  id: string;
  title: string;
  category: 'Cash & Banking' | 'Accruals & Prepaids' | 'Revenue & AR' | 'Payroll & Tax' | 'Reporting & Sign-off';
  assignee: string;
  assigneeRole: string;
  status: 'completed' | 'in_progress' | 'pending' | 'blocked';
  dueDate: string;
  signOffRole: 'Preparer' | 'Reviewer' | 'CFO';
  completedAt?: string;
  signedBy?: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  user: string;
  role: string;
  action: string;
  details: string;
  ipAddress: string;
}

export interface ErpConnection {
  id: string;
  name: ErpSource;
  companyName: string;
  status: 'connected' | 'syncing' | 'error';
  lastSync: string;
  accountCount: number;
  unreconciledCount: number;
  tokenExpiresIn: string;
  authMethod: string;
  health: 'Healthy' | 'Needs Re-auth' | 'Sync Warning';
}

export interface BankAccountSummary {
  id: string;
  name: string;
  accountNumber: string;
  bankName: string;
  currency: string;
  statementEndingBalance: number;
  glEndingBalance: number;
  depositsInTransit: number;
  outstandingChecks: number;
  adjustedBankBalance: number;
  variance: number;
  unmatchedCount: number;
  lastImportDate: string;
}

export interface CloseSummaryData {
  executiveHeadline: string;
  auditOpinion: string;
  balanceTieOutNarrative: string;
  internalControlNotes: string;
  signOffRecommendation: string;
}
