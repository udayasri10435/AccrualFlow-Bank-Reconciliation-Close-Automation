import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize Gemini SDK if key exists
let aiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    aiClient = new GoogleGenAI({});
  } catch (e) {
    console.warn('Failed to initialize GoogleGenAI client:', e);
  }
}

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString(), aiReady: !!process.env.GEMINI_API_KEY });
});

// AI: Investigate Anomaly
app.post('/api/ai/investigate-anomaly', async (req, res) => {
  const { anomaly, transaction, bankAccount } = req.body;
  if (!anomaly) {
    return res.status(400).json({ error: 'Anomaly object is required' });
  }

  if (aiClient) {
    try {
      const prompt = `You are a Senior Corporate Controller and CPA specializing in bank reconciliation, SOX compliance, and GAAP accounting.
Analyze this flagged accounting anomaly:
- Title: ${anomaly.title}
- Type: ${anomaly.type}
- Severity: ${anomaly.severity}
- Description: ${anomaly.description}
- Transaction Details: ${JSON.stringify(transaction || {})}
- Account: ${bankAccount || 'Main Operating Account'}

Provide a structured financial analysis in valid JSON format only (do NOT include markdown code blocks, return raw JSON string with keys):
{
  "summary": "1-2 sentence executive assessment of risk and materiality",
  "rootCauseHypothesis": "Why this discrepancy most likely occurred (e.g., timing cutoff, merchant fee net deposit, duplicate batch transmission, unauthorized ACH)",
  "gaapImplication": "Relevant accounting standard or SOX control implication (e.g., ASC 606, Cutoff assertion, Cash safeguard)",
  "recommendedAction": "Actionable step for the accounting staff",
  "suggestedJournalEntry": {
    "needed": true,
    "debitAccount": "e.g. 6140 Bank & Merchant Service Fees",
    "creditAccount": "e.g. 1010 Operating Cash",
    "amount": ${transaction?.amount ? Math.abs(transaction.amount) : 0},
    "memo": "e.g. Reconcile timing variance / stripe fee deduction"
  }
}`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
      });

      const text = response.text || '';
      // Clean possible markdown code fences
      const cleanJson = text.replace(/```json/gi, '').replace(/```/g, '').trim();
      try {
        const parsed = JSON.parse(cleanJson);
        return res.json({ analysis: parsed, provider: 'gemini' });
      } catch (jsonErr) {
        // Fallback to text parsing
        return res.json({
          analysis: {
            summary: text.slice(0, 200),
            rootCauseHypothesis: "Discrepancy identified during statement reconciliation.",
            gaapImplication: "Internal control review required under SOX Sec 404.",
            recommendedAction: "Verify with vendor statement or review supporting invoice.",
            suggestedJournalEntry: {
              needed: true,
              debitAccount: "6140 General Expense Adjustments",
              creditAccount: "1010 Operating Cash Clearing",
              amount: transaction?.amount || 0,
              memo: "Audit adjustment for period close"
            }
          },
          provider: 'gemini-fallback'
        });
      }
    } catch (err: any) {
      console.error('Gemini error:', err?.message || err);
    }
  }

  // Heuristic rule-based fallback
  const amount = Math.abs(transaction?.amount || 1420);
  const isDuplicate = anomaly.type === 'duplicate';
  const isCutoff = anomaly.type === 'cutoff';
  const isFeeSlip = anomaly.type === 'fee_slippage';

  const heuristic = {
    summary: isDuplicate
      ? `Material duplicate charge risk of $${amount.toLocaleString()} identified across multiple cleared records.`
      : isCutoff
      ? `Timing cutoff anomaly: transaction dated near period-end cleared in subsequent cycle.`
      : isFeeSlip
      ? `Net settlement variance of $${amount.toLocaleString()}: payment processor deducted interchange/merchant fees before deposit.`
      : `High-risk transaction requires controller verification prior to ledger lock.`,
    rootCauseHypothesis: isDuplicate
      ? "Likely automated retry by vendor subscription billing engine or duplicate batch ingestion from bank webhook."
      : isCutoff
      ? "Bank deposit initiated prior to 5:00 PM EST cutoff cleared on following business day."
      : "Automated merchant fee deduction without corresponding split fee entry in general ledger.",
    gaapImplication: "SOX 404 Completeness & Cutoff Assertion. Timely correction prevents misstatement of cash and current assets.",
    recommendedAction: isDuplicate
      ? "Contact vendor for credit memo or reverse duplicate disbursement."
      : "Book timing adjustment or mark as Deposit in Transit on reconciliation tie-out.",
    suggestedJournalEntry: {
      needed: !isDuplicate,
      debitAccount: isFeeSlip ? "6150 Merchant Processing Fees" : "1030 Clearing Suspense",
      creditAccount: "1010 Cash Operating",
      amount: amount,
      memo: `Auto-generated reconciliation adjustment: ${anomaly.title}`
    }
  };

  res.json({ analysis: heuristic, provider: 'heuristic-engine' });
});

// AI: Close Summary Commentary
app.post('/api/ai/close-summary', async (req, res) => {
  const { period, stats, unmatchedCount, reconciledBalance, bankBalance, variance } = req.body;

  if (aiClient) {
    try {
      const prompt = `You are a corporate Controller preparing an executive Month-End Close Sign-Off Summary for Period ${period || 'September 2026'}.
Reconciliation Stats:
- Bank Statement Balance: $${(bankBalance || 0).toLocaleString()}
- Reconciled GL Balance: $${(reconciledBalance || 0).toLocaleString()}
- Net Variance: $${(variance || 0).toLocaleString()}
- Total Matched: ${stats?.matched || 0}
- Unmatched Remaining: ${unmatchedCount || 0}
- Flagged Anomalies: ${stats?.anomalies || 0}
- Integrations: NetSuite, QuickBooks Online, Xero (All Active)

Return raw JSON only (no markdown):
{
  "executiveHeadline": "Concise 1-line statement on close readiness",
  "auditOpinion": "Audit-Ready or Action-Required",
  "balanceTieOutNarrative": "1-2 paragraphs detailing reconciliation status, outstanding deposits in transit, uncleared checks, and variance justification",
  "internalControlNotes": "Key controls validated (Segregation of Duties, Bank Authorization, Cutoff checks)",
  "signOffRecommendation": "Proceed to lock period or pending items summary"
}`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
      });

      const cleanJson = (response.text || '').replace(/```json/gi, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleanJson);
      return res.json({ summary: parsed, provider: 'gemini' });
    } catch (err: any) {
      console.error('Gemini close summary error:', err?.message || err);
    }
  }

  // Heuristic close summary
  const isZeroVariance = Math.abs(variance || 0) < 0.01;
  res.json({
    summary: {
      executiveHeadline: isZeroVariance
        ? `Period ${period || 'September 2026'} Cash Reconciliation is fully tied out ($0.00 variance). Ready for Controller sign-off.`
        : `Period ${period || 'September 2026'} has $${Math.abs(variance || 0).toLocaleString()} outstanding variance requiring resolution before hard lock.`,
      auditOpinion: isZeroVariance ? "Audit-Ready (Unqualified)" : "Action-Required (Pending Tie-Out)",
      balanceTieOutNarrative: `The Operating and Merchant bank accounts have completed automated matching across 3 connected ERP ledgers (NetSuite, QuickBooks, Xero). All deposits in transit and outstanding disbursements have been scheduled with supporting subledger references. Zero unexplained differences remain for material thresholds.`,
      internalControlNotes: "Dual authorization verified: Preparer review completed. Cutoff dates confirmed against banking partner statement cycles.",
      signOffRecommendation: isZeroVariance
        ? "Authorize permanent period lock across NetSuite and QuickBooks ledgers."
        : "Resolve the remaining flagged items before executing formal period closure."
    },
    provider: 'heuristic-engine'
  });
});

// Integrations Sync Simulation
app.post('/api/integrations/sync', (req, res) => {
  const { platform } = req.body;
  const validPlatforms = ['netsuite', 'quickbooks', 'xero'];
  const target = (platform || 'all').toLowerCase();

  res.json({
    success: true,
    platform: target,
    syncedAt: new Date().toISOString(),
    transactionsPulled: Math.floor(Math.random() * 15) + 8,
    glBatchesProcessed: 3,
    status: 'HEALTHY',
    tokenExpiresIn: '179 days',
    latencyMs: 142
  });
});

// Server boot with Vite middleware
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AccrualFlow server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
